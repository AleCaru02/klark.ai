import{a as r}from"./addDays-B4NevTgu.js";function t(a,s){return r(a,-s)}export{t as s};
