import{b as o}from"./isSameMonth-hLDvvJwQ.js";function d(a,r){return o(a,r*12)}export{d as a};
